'use client'

import { useEffect, useRef } from 'react'
import { motion } from 'framer-motion'
import { Mail, Phone, MapPin } from 'lucide-react'

/* ── Particle system ─────────────────────────────── */
function initParticles(canvas: HTMLCanvasElement) {
  const ctx = canvas.getContext('2d')!
  let W = canvas.width = canvas.offsetWidth
  let H = canvas.height = canvas.offsetHeight

  const N = 80
  const particles = Array.from({ length: N }, () => ({
    x: Math.random() * W,
    y: Math.random() * H,
    r: Math.random() * 1.5 + 0.3,
    vx: (Math.random() - 0.5) * 0.3,
    vy: (Math.random() - 0.5) * 0.3,
    opacity: Math.random() * 0.6 + 0.1,
  }))

  let raf: number
  const draw = () => {
    ctx.clearRect(0, 0, W, H)
    particles.forEach((p) => {
      p.x += p.vx; p.y += p.vy
      if (p.x < 0) p.x = W; if (p.x > W) p.x = 0
      if (p.y < 0) p.y = H; if (p.y > H) p.y = 0

      // Draw dot
      ctx.beginPath()
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2)
      ctx.fillStyle = `rgba(0,212,255,${p.opacity})`
      ctx.fill()

      // Draw connections
      particles.forEach((q) => {
        const dx = p.x - q.x, dy = p.y - q.y
        const dist = Math.sqrt(dx * dx + dy * dy)
        if (dist < 120) {
          ctx.beginPath()
          ctx.moveTo(p.x, p.y)
          ctx.lineTo(q.x, q.y)
          ctx.strokeStyle = `rgba(0,212,255,${0.06 * (1 - dist / 120)})`
          ctx.lineWidth = 0.5
          ctx.stroke()
        }
      })
    })
    raf = requestAnimationFrame(draw)
  }

  draw()

  const onResize = () => {
    W = canvas.width = canvas.offsetWidth
    H = canvas.height = canvas.offsetHeight
  }
  window.addEventListener('resize', onResize)
  return () => { cancelAnimationFrame(raf); window.removeEventListener('resize', onResize) }
}

/* ── Component ───────────────────────────────────── */
export default function Hero() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (canvasRef.current) return initParticles(canvasRef.current)
  }, [])

  return (
    <section
      id="hero"
      className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden bg-obsidian"
      aria-label="Hero section"
    >
      {/* Particle canvas */}
      <canvas ref={canvasRef} id="particle-canvas" aria-hidden="true" />

      {/* Grid overlay */}
      <div className="absolute inset-0 bg-grid opacity-20" />

      {/* Ambient glow blobs */}
      <div className="absolute top-1/3 left-1/4 w-[600px] h-[600px] rounded-full blur-[120px] pointer-events-none"
        style={{ background: 'radial-gradient(circle, rgba(0,212,255,0.08) 0%, transparent 70%)' }} />
      <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] rounded-full blur-[100px] pointer-events-none"
        style={{ background: 'radial-gradient(circle, rgba(255,107,43,0.06) 0%, transparent 70%)' }} />

      {/* Scan line */}
      <div className="scan-line" aria-hidden="true" />

      {/* Content */}
      <div className="relative z-10 text-center px-6 max-w-5xl mx-auto">

        {/* Pre-label */}
        <motion.div
          className="flex items-center justify-center gap-3 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.6 }}
        >
          <div className="h-px w-16 bg-gradient-to-r from-transparent to-cyan-glow" />
          <span className="section-label">HSE Professional</span>
          <div className="h-px w-16 bg-gradient-to-l from-transparent to-cyan-glow" />
        </motion.div>

        {/* Name */}
        <motion.h1
          className="font-display font-black mb-4 leading-none"
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        >
          <span
            className="block text-[clamp(3rem,12vw,9rem)] text-gradient-hero"
            style={{ letterSpacing: '-0.02em' }}
          >
            IRSHAD N
          </span>
        </motion.h1>

        {/* Role badge */}
        <motion.div
          className="inline-flex items-center gap-2 px-6 py-2 rounded-full mb-8 border border-cyan-glow/20"
          style={{ background: 'rgba(0,212,255,0.06)' }}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.4, duration: 0.5 }}
        >
          <span className="w-2 h-2 rounded-full bg-cyan-glow animate-pulse" />
          <span className="font-display text-sm tracking-[0.2em] text-cyan-glow">
            HSE Officer &nbsp;|&nbsp; Safety Supervisor
          </span>
          <span className="w-2 h-2 rounded-full bg-amber-glow animate-pulse" style={{ animationDelay: '0.5s' }} />
        </motion.div>

        {/* Tagline */}
        <motion.p
          className="font-body text-lg md:text-xl text-ice-dim max-w-2xl mx-auto mb-12 leading-relaxed"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.6 }}
        >
          Safeguarding lives across oil & gas refineries and industrial facilities.
          <br className="hidden md:block" />
          <span className="text-gradient-fire font-medium"> Zero incidents. Zero compromises.</span>
        </motion.p>

        {/* CTAs */}
        <motion.div
          className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.65, duration: 0.6 }}
        >
          <a
            href="/Irshad_N_HSE_Resume.pdf"
            download
            className="btn-cyan flex items-center gap-2"
            aria-label="Download CV"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
            DOWNLOAD CV
          </a>

          <button
            onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
            className="btn-outline-cyan flex items-center gap-2"
          >
            HIRE ME
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </button>
        </motion.div>

        {/* Quick contact info */}
        <motion.div
          className="flex flex-col sm:flex-row items-center justify-center gap-6 text-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.6 }}
        >
          {[
            { icon: Phone, text: '+91 80896 51072', href: 'tel:+918089651072' },
            { icon: Mail, text: 'irshadnoushad98@gmail.com', href: 'mailto:irshadnoushad98@gmail.com' },
            { icon: MapPin, text: 'Kollam, Kerala', href: '#' },
          ].map(({ icon: Icon, text, href }) => (
            <a
              key={text}
              href={href}
              className="flex items-center gap-2 text-ice-dim hover:text-cyan-glow transition-colors duration-300"
            >
              <Icon size={14} className="text-cyan-glow/60" />
              <span className="font-body text-xs tracking-wide">{text}</span>
            </a>
          ))}
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 0.6 }}
      >
        <span className="font-display text-[10px] tracking-[0.3em] text-ice-muted">SCROLL</span>
        <div className="w-5 h-8 rounded-full border border-white/20 flex items-start justify-center pt-1.5">
          <motion.div
            className="w-1 h-2 rounded-full bg-cyan-glow"
            animate={{ y: [0, 12, 0] }}
            transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
          />
        </div>
      </motion.div>

      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-obsidian to-transparent pointer-events-none" />
    </section>
  )
}
